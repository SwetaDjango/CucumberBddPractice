package stepDefinition;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	
	@Before("@WebTest")
	public void beforeValidation() {
		System.out.println("Before Web Hook");
	}
	
	@After("@WebTest")
	public void afterValidation() {
		System.out.println("After Web Hook");
	}
	
	@Before("@MobileTest")
	public void beforeMobileValidation() {
		System.out.println("Before Mobile Test case Hook");
	}
	
	@After("@MobileTest")
	public void afterMobileValidation() {
		System.out.println("After Mobile Test case Hook");
	}

}
