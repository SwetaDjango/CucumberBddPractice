package stepDefinition;



import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class stepDefinition {
	 public WebDriver driver ;
	 public String landingpageProductName;
	 public String offerpageProductname;
	
		
		  @Given("^User is on Netbanking landing page$") public void
		  User_is_on_Netbanking_landing_page() {
		  
		  System.out.println("User is on Netbanking landing page"); }
		  
		  
		  @When("^User login to application with username and password$") public void
		  User_login_to_application() {
		  
		  //test code wil go here
		  System.out.println("user is logged into application"); }
		 
	  
	  @Then("^Home page is populated$")
	  public void Home_page_is_populated() {
	  
	  //test code wil go here 
		  System.out.println("Home page is populated");
		  }
	  
	  @And("^cards are displayed$")
	  public void cards_are_displayed() {
	  
	  //test code wil go here 
		  System.out.println("Cards are displayed");
		  }
	  
	    @When("^User login to application with \"([^\"]*)\" and password \"([^\"]*)\"$")
	    public void user_login_to_application_with_something_and_password_something(String strArg1, String strArg2) throws Throwable {
	       System.out.println(strArg1);
	       System.out.println(strArg2);
	    }
	    

	    @And("^cards displayed are \"([^\"]*)\"$")
	    public void cards_displayed_are_something(String strArg1) throws Throwable {
	       System.out.println(strArg1);
	    }

	    
	    @When("^User signup with following details$")
	    public void user_signup_with_following_details(DataTable data) throws Throwable {
	   
	 	   List<List<String>> obj = data.asLists();
	 	   
		   System.out.println(obj.get(0).get(0));
		   System.out.println(obj.get(0).get(1));
		   System.out.println(obj.get(0).get(2));
		   System.out.println(obj.get(0).get(3));
		   System.out.println(obj.get(0).get(4));
	    	
	        
	    }
	    
	    @When("^User log in to application with (.+) and password (.+)$")
	    public void user_log_in_to_application_with_and_password(String username, String password) throws Throwable {
	    	
	        System.out.println(username);
	        System.out.println(password);
	    }
	    
	    
	    @Given("User is on GreenCart Landing page")
	    public void user_is_on_green_cart_landing_page() {
	        // Write code here that turns the phrase above into concrete actions
	    	driver = new ChromeDriver();
	    	System.setProperty("webdriver.chrome.driver", "D:\\Sweta\\Web_Drivers\\chromedriver.exe");
	    	driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
	       
	    }
	    @When("user searched with Shortname {string} and extracted actual name of product")
	    public void user_searched_with_shortname_and_extracted_actual_name_of_product(String string) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
		       driver.findElement(By.xpath("//input[@type='search']")).sendKeys(string);
		       Thread.sleep(5000);
		       String landingpageProductName =driver.findElement(By.xpath("//h4[@class='product-name']")).getText().split("-")[0].trim();
		       System.out.println( landingpageProductName + " is extracted from HomePage");
	    }
	    @Then("user searched for {string} shortname in offers page")
	    public void user_searched_for_shortname_in_offers_page(String string) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        driver.findElement(By.linkText("Top Deals")).click();
	        Set<String> s1=driver.getWindowHandles();
	        Iterator<String> i1=s1.iterator();
	        String parentWindow= i1.next();// o index parent window
	        String childWindow = i1.next(); // 1 st index 
	        driver.switchTo().window(childWindow);
	        Thread.sleep(2000);
	        driver.findElement(By.id("search-field")).sendKeys(string);
	        Thread.sleep(3000);
	        String offerpageProductname = driver.findElement(By.xpath("//td[contains(.,'Tomato')]")).getText();
	        
	    }
	    @Then("validate product name in offers page matches with Landing Page")
	    public void validate_product_name_in_offers_page_matches_with_landing_page() {
	        // Write code here that turns the phrase above into concrete actions
	    	Assert.assertEquals(landingpageProductName,offerpageProductname);
	        
	    }

	    
	    @When("^the user opens the browser$")
	    public void the_user_opens_the_browser() throws Throwable {
	       System.out.println("Browser is opened");
	    }

	    @When("^User enters his username and passowrd$")
	    public void user_enters_his_username_and_passowrd() throws Throwable {
	    	System.out.println("Background- User have entered his name and password");
	        
	    }

	    @Then("^User enters the url for netbanking$")
	    public void user_enters_the_url_for_netbanking() throws Throwable {
	    	System.out.println("Url is entered");
	        
	    }

	    @Then("^user is on netbanking home page$")
	    public void user_is_on_netbanking_home_page() throws Throwable {
	        System.out.println("Background completed . user is on netbanking home page");
	    }

}
